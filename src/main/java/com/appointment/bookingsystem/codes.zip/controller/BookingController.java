package com.appointment.bookingsystem.controller;

import com.appointment.bookingsystem.service.BookingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/bookings")
@CrossOrigin(origins = "*")
public class BookingController {

    @Autowired
    private BookingService bookingService;

    // Book appointment for a registered user
    @PostMapping("/user")
    public String bookForUser(@RequestParam Long appointmentId, @RequestParam Long userId) {
        boolean booked = bookingService.bookForUser(appointmentId, userId);
        return booked ? "Appointment booked successfully for user" : "Booking failed";
    }

    // Book appointment for a guest
    @PostMapping("/guest")
    public String bookForGuest(
            @RequestParam Long appointmentId,
            @RequestParam String guestName,
            @RequestParam String guestPhone,
            @RequestParam String guestEmail) {

        boolean booked = bookingService.bookForGuest(appointmentId, guestName, guestPhone, guestEmail);
        return booked ? "Appointment booked successfully for guest" : "Booking failed";
    }
}
