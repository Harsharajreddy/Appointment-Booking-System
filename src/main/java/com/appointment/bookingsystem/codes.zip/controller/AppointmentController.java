package com.appointment.bookingsystem.controller;

import com.appointment.bookingsystem.model.Appointment;
import com.appointment.bookingsystem.service.AppointmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/appointments")
@CrossOrigin(origins = "*")
public class AppointmentController {

    @Autowired
    private AppointmentService appointmentService;

    @GetMapping("/available")
    public List<Appointment> getAvailableAppointments() {
        return appointmentService.getAvailableAppointments();
    }

    @PostMapping("/book/{id}")
    public ResponseEntity<String> bookAppointment(@PathVariable Long id) {
        boolean booked = appointmentService.bookAppointment(id);

        if (booked) {
            return ResponseEntity.ok("Appointment booked successfully");
        } else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Appointment already booked or not found");
        }
    }

}
