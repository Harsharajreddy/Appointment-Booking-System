package com.appointment.bookingsystem.controller;

import com.appointment.bookingsystem.dto.LoginRequest;
import com.appointment.bookingsystem.model.User;
import com.appointment.bookingsystem.service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "*")
public class AuthController {

    @Autowired
    private AuthService authService;

    // Signup API
    @PostMapping("/signup")
    public String signup(@RequestBody User user) {
        System.out.println("Received Signup Request: " + user);
        System.out.println("Email: " + user.getEmail()); // Debug log
        return authService.registerUser(user);
    }

    // Login API
    @PostMapping("/login")
    public ResponseEntity<Map<String, String>> loginUser(@RequestBody LoginRequest request) {
        String token = authService.loginUser(request.getEmail(), request.getPassword());
        System.out.println("✅ Generated Token: " + token);
        return ResponseEntity.ok(Collections.singletonMap("token", token));
    }
}
