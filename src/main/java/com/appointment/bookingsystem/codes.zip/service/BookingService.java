package com.appointment.bookingsystem.service;

import com.appointment.bookingsystem.model.Appointment;
import com.appointment.bookingsystem.model.Booking;
import com.appointment.bookingsystem.model.User;
import com.appointment.bookingsystem.repository.AppointmentRepository;
import com.appointment.bookingsystem.repository.BookingRepository;
import com.appointment.bookingsystem.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Optional;

@Service
public class BookingService {

    @Autowired
    private BookingRepository bookingRepository;

    @Autowired
    private AppointmentRepository appointmentRepository;

    @Autowired
    private UserRepository userRepository;

    // Book an appointment for a registered user
    public boolean bookForUser(Long appointmentId, Long userId) {
        Optional<Appointment> appointmentOpt = appointmentRepository.findById(appointmentId);
        Optional<User> userOpt = userRepository.findById(userId);

        if (appointmentOpt.isPresent() && userOpt.isPresent()) {
            Appointment appointment = appointmentOpt.get();
            User user = userOpt.get();

            if (appointment.getStatus() == Appointment.Status.AVAILABLE) {
                appointment.setStatus(Appointment.Status.BOOKED);
                appointmentRepository.save(appointment);

                Booking booking = Booking.builder()
                        .appointment(appointment)
                        .user(user)
                        .build();
                bookingRepository.save(booking);
                return true;
            }
        }
        return false;
    }

    // Book an appointment for a guest
    public boolean bookForGuest(Long appointmentId, String guestName, String guestPhone, String guestEmail) {
        Optional<Appointment> appointmentOpt = appointmentRepository.findById(appointmentId);

        if (appointmentOpt.isPresent()) {
            Appointment appointment = appointmentOpt.get();

            if (appointment.getStatus() == Appointment.Status.AVAILABLE) {
                appointment.setStatus(Appointment.Status.BOOKED);
                appointmentRepository.save(appointment);

                Booking booking = Booking.builder()
                        .appointment(appointment)
                        .guestName(guestName)
                        .guestPhone(guestPhone)
                        .guestEmail(guestEmail)
                        .build();
                bookingRepository.save(booking);
                return true;
            }
        }
        return false;
    }
}
