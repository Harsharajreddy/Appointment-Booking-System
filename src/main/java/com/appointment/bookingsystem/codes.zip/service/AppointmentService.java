package com.appointment.bookingsystem.service;

import com.appointment.bookingsystem.model.Appointment;
import com.appointment.bookingsystem.model.Appointment.Status;
import com.appointment.bookingsystem.repository.AppointmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

@Service
public class AppointmentService {

    @Autowired
    private AppointmentRepository appointmentRepository;

    // Generate appointments for the next 7 days
    public void generateAppointments() {
        LocalDate today = LocalDate.now();
        LocalTime startTime = LocalTime.of(9, 0);
        LocalTime endTime = LocalTime.of(18, 0);

        List<Appointment> appointments = IntStream.range(0, 7)
                .mapToObj(i -> today.plusDays(i))
                .flatMap(date -> IntStream.range(0, 9)
                        .mapToObj(i -> Appointment.builder()
                                .date(date)
                                .time(startTime.plusHours(i))
                                .status(Status.AVAILABLE)
                                .build()))
                .collect(Collectors.toList());

        appointmentRepository.saveAll(appointments);
    }

    // Fetch available appointments for the next 7 days
    public List<Appointment> getAvailableAppointments() {
        LocalDate today = LocalDate.now();
        LocalDate nextWeek = today.plusDays(7);

        return appointmentRepository.findByDateBetween(today, nextWeek)
                .stream()
                .filter(appointment -> appointment.getStatus() == Appointment.Status.AVAILABLE)
                .collect(Collectors.toList());
    }


    // Book an appointment
    public boolean bookAppointment(Long appointmentId) {
        Optional<Appointment> appointmentOpt = appointmentRepository.findById(appointmentId);

        if (appointmentOpt.isPresent()) {
            Appointment appointment = appointmentOpt.get();
            if (appointment.getStatus() == Status.AVAILABLE) {
                appointment.setStatus(Status.BOOKED);
                appointmentRepository.save(appointment);
                return true;
            }
        }
        return false; // Already booked or not found
    }
}
