package com.appointment.bookingsystem.service;

import com.appointment.bookingsystem.model.User;
import com.appointment.bookingsystem.repository.UserRepository;
import com.appointment.bookingsystem.security.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class AuthService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private JwtUtil jwtUtil;

    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    public String registerUser(User user) {
        user.setPassword(passwordEncoder.encode(user.getPassword())); // Hash password before saving
        userRepository.save(user);
        return "User registered successfully!";
    }

    public String loginUser(String email, String password) {
        Optional<User> optionalUser = userRepository.findByEmail(email);
        User user = optionalUser.orElse(null);

        if (user == null) {
            return "User not found!";
        }

        if (!passwordEncoder.matches(password, user.getPassword())) {
            return "Invalid credentials!";
        }

        // ✅ Convert Role Enum to String
        String token = jwtUtil.generateToken(user.getEmail(), user.getRole().name());

        return "{ \"token\": \"" + token + "\" }";
    }
}
